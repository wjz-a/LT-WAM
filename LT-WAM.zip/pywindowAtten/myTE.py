import numpy
import torch
from torch.autograd import Variable
import numpy as np
import torch.nn as nn

def timeEmbedding(times,maxNum,size):
    embed = nn.Embedding(maxNum, size)
    voc_embed_0 = embed(Variable(torch.LongTensor(times)))
    return voc_embed_0


class PositionalEncoding(nn.Module):

    def __init__(self, max_seq_len, d_model):

        super(PositionalEncoding, self).__init__()

        position_encoding = np.array([
            [pos / np.power(10000, 2.0 * (j // 2) / d_model) for j in range(d_model)]
            for pos in range(max_seq_len + 1)])
        position_encoding[:, 0::2] = np.sin(position_encoding[:, 0::2])
        position_encoding[:, 1::2] = np.cos(position_encoding[:, 1::2])
        position_encoding = torch.from_numpy(position_encoding)
        self.position_encoding = nn.Embedding(max_seq_len + 1, d_model)
        self.position_encoding.weight = nn.Parameter(position_encoding,
                                                     requires_grad=False)


def getTime():
    times = []
    for i in range(15):
        for hours in range(24):
            for minutes in range(12):
                temp = np.array([hours, minutes * 5])
                times.append(temp)
    print(times)
    times = np.array(times)
    print(times)
    return times

def getTimer(num):
    times = []
    order = 0
    week = 4
    for i in range(num):
        week = week%7
        order = order%288
        temp = np.array([week, order])
        times.append(temp)
        week = week+1
        order = order+1
    print(times)
    times = np.array(times)
    print(times)
    return times

def getEm(times,maxNum,size):
    P = PositionalEncoding(maxNum, size)
    voc_embed_1 = P.position_encoding(Variable(torch.LongTensor(times)))
    voc_embed_0 = timeEmbedding(times,maxNum,size)

    res = torch.cat((voc_embed_0,voc_embed_1),2)
    return res

def getTestValue():
    times = []
    for i in range(10):
        for hours in range(24):
            two = []
            for minutes in range(2):
                temp = np.array([hours, minutes * 5])
                two.append(temp)
            times.append(two)
    print(times)
    times = np.array(times)
    print(times)
    return times


if __name__ == '__main__':
    times = getTestValue()

    res = getEm(times,60,12)
    res = res.transpose(1,2)
    print(res)
